package ceshi;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import shixun.Glyjiemian;
import shixun.Pay;

public class shiyan {
public static void main(String[] args) {
	chazhao();
}
public static void chazhao(){
	Scanner input=new Scanner(System.in);
	System.out.println("������Ա���ţ�");
	Pay pay=new Pay();
	  pay.setSno(input.nextLine().trim());
	  while(pay.getSno().equals("")){
	      System.err.println("�������Ա����Ϊ�գ����������룡");
	      pay.setSno(input.nextLine().trim());
	      }
	try{
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql:"
				+ "//localhost:3306/rsxxgl","root","root");
		String sql="SELECT * FROM pay where sno='"+pay.getSno()+"';";
		Statement st=con.createStatement();
		ResultSet in=st.executeQuery(sql);
		if(in.next()){
			String sql1="SELECT * FROM pay where sno='"+pay.getSno()+"';";
			ResultSet in1=st.executeQuery(sql1);
			while(in1.next()){
				String sno=in1.getString("sno");
				String dno=in1.getString("dno");
				double abasicwage=in1.getDouble("abasicwage");
				double aattwage=in1.getDouble("aattwage");
				double atotalwage=in1.getDouble("atotalwage");
				System.out.println("Ա����\t|\t���ź�\t|\t��������\t|\t���ڹ���\t|\t�ܹ���");
				System.out.println(sno+"\t|\t"+dno+"\t|\t"+abasicwage+"\t|\t"+aattwage+"\t|\t"+atotalwage);
			}
		}
		else{
			System.err.println("�û������ڣ�����������");
		}
	}catch(Exception e){
		e.printStackTrace();
	}
}
}
