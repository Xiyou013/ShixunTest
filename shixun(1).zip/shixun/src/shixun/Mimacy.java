package shixun;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Mimacy {
	public static int glmima(String pass){
		if(pass.equals("")){
			return 0;
	    	}
		else if(pass.length()<=5||pass.length()>=17){
				return 1;
    	}else{
    		return 2;
    	}
	}
	public static int ygsno(String sno){
		if(sno.equals("")){
			return 0;
	    	}
		else if(sno.length()!=6){
				return 1;
    	}else{
    		return 2;
    	}
	}
	public static int bmdno(String dno){
		if(dno.equals("")){
			return 0;
		}
		else if(dno.length()!=3){
			return 1;
		}
		else{
			return 2;
		}
	}
	public static int phone(String phone){
		if(phone.equals("")){
			return 0;
		}else if(phone.length()!=11){
			return 1;
		}else {
			String regex="^((13[0-9])|(14[5|7])|(15([0-3]|[5-9]))|(17[013678])|(18[0,5-9]))\\d{8}$";
			Pattern p=Pattern.compile(regex);
			Matcher m=p.matcher(phone);
			boolean isMatch=m.matches();
			if(!isMatch){
				return 2;
			}else{
				return 3;
			}
		
		}
	}
	public static int age(int age){
		String val=age+"";
		if("".equals(val)){
			return 0;
		}else if(age==0){
			return 1;
		}
		else{
			return 2;
		}
	}
	
	public static int ssex(String sex){
		String man="��";
		String woman="Ů";
		if(sex.equals(man)){
			return 1;
		}else if(sex.equals(woman)){
			return 1;
		}else{
			return 0;
		}
	}
	
	
	
}
