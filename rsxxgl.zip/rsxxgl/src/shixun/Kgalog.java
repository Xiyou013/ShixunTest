package shixun;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Kgalog {
	public static void kgloag(Staff staff){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rsxxgl","root","root");
			 Statement st = con.createStatement();
			 String sql="select* from attendance where Sno='"+staff.getSno()+"'and Psignin='1';";
			 ResultSet sel = st.executeQuery(sql);
			 double num=0;
			 while(sel.next()){
				 num++;
			 }
			 
			 String sql1="SELECT * FROM pay WHERE sno='"+staff.getSno()+"';";
			 ResultSet sel1 = st.executeQuery(sql1);
			 if(sel1.next()){
				 double attwage=(num/30)*500;
				 String atwage= String.format("%.2f",attwage);
				
				 String sql2="UPDATE pay SET aattwage='"+atwage+"' WHERE sno='"+staff.getSno()+"';";
				 int res = st.executeUpdate(sql2);
					if(res!=0){
				
					}else{
						
					}
			 }else{
				 
			 }
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
