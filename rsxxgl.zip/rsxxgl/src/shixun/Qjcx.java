package shixun;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class Qjcx {
	public static void qjcx(Staff staff){
		try {
			 Scanner input=new Scanner(System.in);
			
			   
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rsxxgl","root","root");
			    String sql = "select* from attendance where Sno='"+staff.getSno()+"' and pleave='1';";
			    
			    Statement st = con.createStatement();
			    ResultSet res = st.executeQuery(sql);
				
				while(res.next()){
					System.out.println("\tԱ����\t|\t�������\t|\t���ԭ��\t|\t���ʱ��");
					System.out.println("\t"+res.getString(1)+"\t|\t"+res.getString(3)+"\t|\t"+res.getString(4)+"\t|\t"+res.getString(5));
				}
				System.out.println("\n");
				con.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	}

