package shixun;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Gqcx {

	public void kqcx(Staff staff) {
		
	
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rsxxgl","root","root");
			String sql="select* from attendance where Sno='"+staff.getSno()+"'";
			Statement st = con.createStatement();
			
			ResultSet res = st.executeQuery(sql);

			System.out.println("��ѯ�ɹ���");
			while(res.next()){
				System.out.println("\tԱ����\t|\t������\t|\t�������\t|\t���ԭ��");
				System.out.println("\t"+res.getString(1)+"\t|\t"+res.getString(2)+"\t|\t"+res.getString(3)+"\t|\t"+res.getString(4));
			}
			
			con.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
