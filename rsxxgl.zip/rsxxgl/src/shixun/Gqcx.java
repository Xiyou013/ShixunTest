package shixun;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class Gqcx {

	public void kqcx(Staff staff) {
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rsxxgl","root","root");
			String sql="select* from attendance where Sno='"+staff.getSno()+"'";
			Statement st = con.createStatement();
			ResultSet res = st.executeQuery(sql);
			
			if(res.next()){
				String sql1="select* from attendance where Sno='"+staff.getSno()+"'and Psignin='1';";
				
				ResultSet res1 = st.executeQuery(sql1);
				int num = 0;
				while(res1.next()){
					num++;
				}
				
				System.out.println("Ա���ţ�'"+staff.getSno()+"'");
				System.out.println("�򿨴�����");
				System.out.println(num);
				String sql4="select* from attendance where Sno='"+staff.getSno()+"'";
				Statement st1 = con.createStatement();
				
				ResultSet res2 = st1.executeQuery(sql4);
				if(res2.next()){
					String sql2="select* from attendance where Sno='"+staff.getSno()+"'and Pleave='1';";
					
					ResultSet res3 = st1.executeQuery(sql2);
					int num1 = 0;
					while(res3.next()){
						num1++;
					}
					System.out.println("��ٴ�����");
					System.out.println(num1);
				
			}
			}
			System.out.println("\n");
			con.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
