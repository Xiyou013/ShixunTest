package shixun;

public class User {
private String uname;
private String upass;
private String uphone;

public String getUphone() {
	return uphone;
}
public void setUphone(String uphone) {
	this.uphone = uphone;
}
public String getUname() {
	return uname;
}
public void setUname(String uname) {
	this.uname = uname;
}
public String getUpass() {
	return upass;
}
public  void setUpass(String upass) {
	this.upass = upass;
}

}
