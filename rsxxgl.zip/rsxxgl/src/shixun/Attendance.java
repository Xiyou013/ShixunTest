package shixun;

public class Attendance {
private String sno;
private int psignin;
private int pleave;
private String pregleave;
private String ptime;

public String getPtime() {
	return ptime;
}
public void setPtime(String ptime) {
	this.ptime = ptime;
}
public String getSno() {
	return sno;
}
public void setSno(String sno) {
	this.sno = sno;
}
public int getPsignin() {
	return psignin;
}
public void setPsignin(int psignin) {
	this.psignin = psignin;
}
public int getPleave() {
	return pleave;
}
public void setPleave(int pleave) {
	this.pleave = pleave;
}
public String getPregleave() {
	return pregleave;
}
public void setPregleave(String pregleave) {
	this.pregleave = pregleave;
}

}
