package shixun;

import java.awt.event.InputEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class Qj {
	public void qj(Staff staff) {
		try {
			 Scanner input=new Scanner(System.in);
			 System.out.println("���������ԭ��");
			Attendance attendance = new Attendance();
				attendance.setPregleave(input.nextLine().trim());
				while(attendance.getPregleave().equals("")){
		    		System.err.println("������Ϊ�գ�����������");
		    		attendance.setPregleave(input.nextLine().trim());
		    	}
				 
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rsxxgl","root","root");
			    String sql ="insert into attendance (sno,Pleave,pleaveflag,Pregleave) values('"+staff.getSno()+"','1','1','"+attendance.getPregleave()+"');"; 
			    Statement st = con.createStatement();
				int res = st.executeUpdate(sql);
				System.out.println("������ʾ�ϼ������Եȣ�");
	
				
				if(res==1){
					System.out.println("��ٳɹ���");
					
				}else{
					System.out.println("���ʧ�ܣ�");
				}
				
				con.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	
		
		
	}

