package shixun;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import javax.swing.Icon;

public class Bmh {
	
	public static void bmh() {
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rsxxgl","root","root");
			Statement st = con.createStatement();
			Scanner input=new Scanner(System.in);
			System.out.println("��Ӵ��ڵĲ�����ѡ��");
			String sql2="SELECT dno,dname FROM department;";
			ResultSet sel2=st.executeQuery(sql2);
			while(sel2.next()){
				String dno=sel2.getString("dno");
				String dname=sel2.getString("dname");
				System.out.print(dno+":"+dname+"\t");
				
			}
			System.out.println("\n");
			   Staff staff = new Staff();
			   staff.setDno(input.nextLine().trim());
				Mimacy dno=new Mimacy();
		    	int bmdno=dno.bmdno(staff.getDno().trim());
		    	while(bmdno==0||bmdno==1||bmdno==2){
		    		if(bmdno==0){
		    			System.err.println("������Ĳ��ź�Ϊ�գ�����������");
		    			staff.setDno(input.nextLine().trim());
		    			bmdno=dno.bmdno(staff.getDno().trim());
		    		}
		    		else if(bmdno==1){
		    			System.err.println("������Ĳ��źŲ����Ϲ���3λ����,�Ҳ������ո�");
		    			staff.setDno(input.nextLine().trim());
		    			bmdno=dno.bmdno(staff.getDno().trim());
		    		}
		    		else if(bmdno==2){
		    			break;
		    		}
		    	}
			String sql="select* from department where Dno='"+staff.getDno()+"' ";
			ResultSet res = st.executeQuery(sql);
			if(res.next()){
			   System.out.println("��ѯ�ɹ�!");
			   System.out.println("\t���ź�\t|\t������\t|\t������ϵ�绰");
			   System.out.println("\t"+res.getString(1)+"\t|\t"+res.getString(2)+"\t|\t"+res.getString(3));
			 }
			 else{
			   System.err.println("���źŲ����ڣ�����������");
			   bmh();
			  }
			con.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}	

	

	
		
		

	
		
	

		
	

