package shixun;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class Ygkqsel {
	public static void ygkqsel(){
			Scanner input = new Scanner(System.in);
			  System.out.println("������Ա���ţ�");
			  Attendance attendance = new Attendance();
			  attendance.setSno(input.nextLine().trim());
			  Mimacy ygsno=new Mimacy();
		    	int ygsnonum=ygsno.ygsno(attendance.getSno().trim());
		    	while(ygsnonum==0||ygsnonum==1||ygsnonum==2){
		    		if(ygsnonum==0){
		    			System.err.println("�������Ա����Ϊ�գ�����������");
		    			attendance.setSno(input.nextLine().trim());
		    			ygsnonum=ygsno.ygsno(attendance.getSno().trim());
		    		}else if(ygsnonum==1){
		    			System.err.println("�������Ա���Ų����Ϲ������������루6λ����,�Ҳ������ո�");
		    			attendance.setSno(input.nextLine().trim());
		    			ygsnonum=ygsno.ygsno(attendance.getSno().trim());
		    		}else if(ygsnonum==2){
		    			break;
		    		}
		    	}

			  try {

			   Class.forName("com.mysql.jdbc.Driver");
			   Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rsxxgl", "root", "root");
			   String sql = "SELECT * FROM attendance where sno='" + attendance.getSno() + "';";
			   Statement st = con.createStatement();

			   ResultSet res = st.executeQuery(sql);
			   if (res.next()) {
			    String sql1 = "SELECT * FROM staff where sno='" + attendance.getSno() + "';";
			    ResultSet res1 = st.executeQuery(sql1);
			    while (res1.next()) {
			     String sno = res1.getString("sno");
			     int psignin = res1.getInt("psignin");
			     int pleave = res1.getInt("pleave");
			     String pregleave = res1.getString("pregleave");
			      String ptime=res1.getString("ptime");
			     System.out.println("Ա����\t|\t��\t|\t���\t|\t���ԭ��\t|\t����");
			     System.out.println(sno + "\t|\t" + psignin + "\t|\t" + pleave + "\t|\t" + pregleave+ "\t|\t"+ptime);
			    }
			   } else {
			    System.err.println("Ա�������ڣ�����������");
			   }
			   con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		}
}
