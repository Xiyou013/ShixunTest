package shixun;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class Ygkqsel {
	public static void ygkqsel(){
			Scanner input = new Scanner(System.in);
			  System.out.println("������Ա���ţ�");
			  Attendance attendance = new Attendance();
			  attendance.setSno(input.nextLine().trim());
			  Mimacy ygsno=new Mimacy();
		    	int ygsnonum=ygsno.ygsno(attendance.getSno().trim());
		    	while(ygsnonum==0||ygsnonum==1||ygsnonum==2){
		    		if(ygsnonum==0){
		    			System.err.println("�������Ա����Ϊ�գ�����������");
		    			attendance.setSno(input.nextLine().trim());
		    			ygsnonum=ygsno.ygsno(attendance.getSno().trim());
		    		}else if(ygsnonum==1){
		    			System.err.println("�������Ա���Ų����Ϲ������������루6λ����,�Ҳ������ո�");
		    			attendance.setSno(input.nextLine().trim());
		    			ygsnonum=ygsno.ygsno(attendance.getSno().trim());
		    		}else if(ygsnonum==2){
		    			break;
		    		}
		    	}

			  try {

			   Class.forName("com.mysql.jdbc.Driver");
			   Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rsxxgl", "root", "root");
			   String sql = "SELECT * FROM staff where sno='" + attendance.getSno() + "';";
			   Statement st = con.createStatement();
			   Statement sts = con.createStatement();

			   ResultSet res = st.executeQuery(sql);
			   if (res.next()) {
			    String sql1 = "SELECT * FROM attendance where sno='" + attendance.getSno() + "';";
			    ResultSet res1 = st.executeQuery(sql1);
			    if(res1.next()){
			    	String sql2 = "SELECT * FROM attendance where sno='" + attendance.getSno() + "';";
				    ResultSet res2 = sts.executeQuery(sql2);
				    System.out.println("Ա����\t|\t��\t|\t���\t|\t���ԭ��\t|\t����");
				    while (res2.next()) {
					     String sno = res2.getString("sno");
					     int psignin = res2.getInt("psignin");
					     int psigninflag = res2.getInt("psigninflag");
					     int pleave = res2.getInt("pleave");
					     int pleaveflag = res2.getInt("pleaveflag");
					     String pregleave = res2.getString("pregleave");
					      String ptime=res2.getString("ptime");
					    
					     System.out.println(sno + "\t|\t" + psignin +"  "+psigninflag +"\t|\t" + pleave +"  "+pleaveflag+ "\t|\t" + pregleave+ "\t|\t"+ptime);
					    }
			    }else{
			    	System.out.println("û�и�Ա���Ŀ��ڼ�¼");
			    }
			    
			   } else {
			    System.err.println("Ա�������ڣ�����������");
			   }
			   con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		}
}
