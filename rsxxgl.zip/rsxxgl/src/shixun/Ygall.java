package shixun;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class Ygall {
	public static void ygall(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql:"
					+ "//localhost:3306/rsxxgl","root","root");
			Statement st=con.createStatement();
			String sql="SELECT * FROM staff;";
			ResultSet sel=st.executeQuery(sql);
			
			System.out.println("\tԱ����\t|\tԱ������\t|\tԱ���Ա�\t|\tԱ������\t|\tԱ���绰\t\t|\tԱ�����ڲ���");
			int num=0;
			while(sel.next()){
				String sno=sel.getString("sno");
				String sname=sel.getString("sname");
				String ssex=sel.getString("ssex");
				int sage=sel.getInt("sage");
				String sphone=sel.getString("sphone");
				String dno=sel.getString("dno");
				num++;
				System.out.println(num+"\t"+sno+"\t|\t"+sname+"\t|\t"+ssex+"\t|\t"+sage+"\t|\t"+sphone+"\t|\t"+dno);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void ygsel(){
		try {
			System.out.println("������Ա���Ż�Ա��������");
			Scanner input=new Scanner(System.in);
			String cz=input.nextLine().trim();
	    	while(cz.equals("")){
	    		System.err.println("�������Ա����ϢΪ�գ�����������");
	    		cz=input.nextLine().trim();
	    	}
	    	Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql:"
					+ "//localhost:3306/rsxxgl","root","root");
			Statement st=con.createStatement();
			String sql="SELECT * FROM staff where sno='"+cz+"';";
			ResultSet sel=st.executeQuery(sql);
			if(sel.next()){
				String sql1="SELECT * FROM staff where sno='"+cz+"';";
				ResultSet sel1=st.executeQuery(sql1);
				System.out.println("\tԱ����\t|\tԱ������\t|\tԱ���Ա�\t|\tԱ������\t|\tԱ���绰\t\t|\tԱ�����ڲ���");
				int num=0;
				while(sel1.next()){
					String sno=sel1.getString("sno");
					String sname=sel1.getString("sname");
					String ssex=sel1.getString("ssex");
					int sage=sel1.getInt("sage");
					String sphone=sel1.getString("sphone");
					String dno=sel1.getString("dno");
					num++;
					System.out.println(num+"\t"+sno+"\t|\t"+sname+"\t|\t"+ssex+"\t|\t"+sage+"\t|\t"+sphone+"\t|\t"+dno);
				}
			}else if(!sel.next()){
				String sql1="SELECT * FROM staff where sname='"+cz+"';";
				ResultSet sel1=st.executeQuery(sql1);
				if(sel1.next()){
					String sql2="SELECT * FROM staff where sname='"+cz+"';";
					ResultSet sel2=st.executeQuery(sql2);
					System.out.println("\tԱ����\t|\tԱ������\t|\tԱ���Ա�\t|\tԱ������\t|\tԱ���绰\t\t|\tԱ�����ڲ���");
					int num=0;
					while(sel2.next()){
						String sno=sel2.getString("sno");
						String sname=sel2.getString("sname");
						String ssex=sel2.getString("ssex");
						int sage=sel2.getInt("sage");
						String sphone=sel2.getString("sphone");
						String dno=sel2.getString("dno");
						num++;
						System.out.println(num+"\t"+sno+"\t|\t"+sname+"\t|\t"+ssex+"\t|\t"+sage+"\t|\t"+sphone+"\t|\t"+dno);
					}
				}else{
					System.err.println("�Ҳ�����Ա��");
				}
			}else{
				System.err.println("�Ҳ�����Ա��");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
}
