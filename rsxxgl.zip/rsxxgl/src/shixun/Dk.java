package shixun;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class Dk {

	public void dk(Staff staff) {
		 try {
			 Scanner input=new Scanner(System.in);
			
			   System.out.println("���");
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rsxxgl","root","root");
			    String sql = "insert into attendance (sno,Psignin) values('"+staff.getSno()+"','1');";
			    
			    Statement st = con.createStatement();
				int res = st.executeUpdate(sql);
				
				if(res!=0){
					System.out.println("�򿨳ɹ���");
				}else{
					System.out.println("��ʧ�ܣ�");
				}
				Kgalog atwage=new Kgalog();
				atwage.kgloag(Ygdl.staff);
				
				
				
				con.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

