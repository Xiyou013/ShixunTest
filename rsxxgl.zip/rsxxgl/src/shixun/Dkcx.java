package shixun;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class Dkcx {

	public static void dkcx(Staff staff){
		try {
			 Scanner input=new Scanner(System.in);
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rsxxgl","root","root");
				 Statement st = con.createStatement();
				 Statement sts = con.createStatement();
				 Statement st1 = con.createStatement();
				 Statement st2 = con.createStatement();
				
				 String sql1="SELECT * FROM attendance WHERE sno='"+staff.getSno()+"';";
					ResultSet res1 = st1.executeQuery(sql1);
					if(res1.next()){
						 String sql = "select* from attendance where Sno='"+staff.getSno()+"' and psignin='1' and psigninflag='1';";
						    ResultSet res = st.executeQuery(sql);
						    if(res.next()){
						    	String sql3 = "select* from attendance where Sno='"+staff.getSno()+"' and psignin='1' and psigninflag='1';";
							    ResultSet res3 = sts.executeQuery(sql3);
							    System.out.println("\tԱ����\t|\t��\t|\t��ʱ��");
								while(res3.next()){
									System.out.println("\t"+res.getString(1)+"\t|\t"+res.getString(2)+"  "+res.getString(3)+"\t|\t"+res.getString(7));
								}
								
						    }else{
						    	System.out.println("\tԱ����\t|\t��\t|\t��ʱ��");
						    	System.out.println("\t"+staff.getSno()+"\t|\t��\t|\t��");
						    }
						    
						    String sql4 = "select* from attendance where Sno='"+staff.getSno()+"' and psignin='1' and psigninflag='0';";
						    ResultSet res4 = st.executeQuery(sql4);
						    if(res4.next()){
						    	String sql2 = "select* from attendance where Sno='"+staff.getSno()+"' and psignin='1' and psigninflag='0';";
							    ResultSet res2 = st2.executeQuery(sql2);
							    System.out.println("\tԱ����\t|\t����\t|\t����ʱ��");
								while(res2.next()){
									System.out.println("\t"+res2.getString(1)+"\t|\t"+res2.getString(2)+"  "+res2.getString(3)+"\t|\t"+res2.getString(7));
								}
						    }else{
						    	System.out.println("\tԱ����\t|\t����\t|\t����ʱ��");
						    	System.out.println("\t"+staff.getSno()+"\t|\t��\t|\t��");
						    }
							
					}else{
						System.out.println("���޸�Ա���Ĵ���Ϣ");
					}
				con.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
}
