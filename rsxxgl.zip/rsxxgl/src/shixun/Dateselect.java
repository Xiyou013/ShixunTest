package shixun;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class Dateselect {
	public static void dateselect(){
		Scanner input = new Scanner(System.in);
	     System.out.println("��������Ҫ��ѯ������(yyyy-MM-dd)��");
	     Attendance attendance = new Attendance();
	     attendance.setPtime(input.nextLine().trim());
	 
	     Mimacy Date=new Mimacy();
	      int verifyDateNum=Date.Date(attendance.getPtime());
	      while(verifyDateNum == 0 || verifyDateNum == 1|| verifyDateNum == 2) {
	      if(verifyDateNum == 0) {
	       System.err.println("�����������Ϊ�գ�");
	       attendance.setPtime(input.nextLine().trim());
	       verifyDateNum=Date.Date(attendance.getPtime());
	      }else if(verifyDateNum == 1) {
	       System.err.println("����������ڲ����Ϲ���(yyyy-MM-dd)��");
	       attendance.setPtime(input.nextLine().trim());
	       verifyDateNum=Date.Date(attendance.getPtime());
	      }else if(verifyDateNum == 2) {
	        break;
	      }
	     }
	    
	 
	  try {
	      Class.forName("com.mysql.jdbc.Driver");
	      Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rsxxgl", "root", "root");
	      Statement st = con.createStatement();
	      Statement st1 = con.createStatement();
	      
	      String sql = "SELECT * FROM attendance WHERE Ptime LIKE '"+attendance.getPtime()+"%';";
	      ResultSet res=st.executeQuery(sql);
	      if (res.next()) {
	       String sql1 = "SELECT * FROM attendance WHERE Ptime LIKE '"+attendance.getPtime()+"%';";
	   
	          ResultSet res1 = st1.executeQuery(sql1); 
	       
	       while (res1.next()) {
	        String sno = res1.getString("sno");
	        int psignin = res1.getInt("psignin");
	        int pleave = res1.getInt("pleave");
	        String pregleave = res1.getString("pregleave");
	        String ptime=res1.getString("ptime");
	        System.out.println("Ա����\t|\t��\t|\t���\t|\t���ԭ��\t|\t����");
	        System.out.println(sno + "\t|\t" + psignin + "\t|\t" + pleave + "\t|\t" +pregleave+ "\t|\t"+ptime);
	       } 
	      } 
	      else {
	       System.err.println("��������ڲ����ڣ�����������");
	      }
	      con.close();
	     }
	     catch (Exception e) {
	      e.printStackTrace();

	     }
	}
}
