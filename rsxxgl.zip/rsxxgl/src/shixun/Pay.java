package shixun;

public class Pay {
private String sno;
private String dno;
private double abasicwage;
private double aattwage;
private double atotalwage;
public String getSno() {
	return sno;
}
public void setSno(String sno) {
	this.sno = sno;
}
public String getDno() {
	return dno;
}
public void setDno(String dno) {
	this.dno = dno;
}
public double getAbasicwage() {
	return abasicwage;
}
public void setAbasicwage(double abasicwage) {
	this.abasicwage = abasicwage;
}
public double getAattwage() {
	return aattwage;
}
public void setAattwage(double aattwage) {
	this.aattwage = aattwage;
}
public double getAtotalwage() {
	return atotalwage;
}
public void setAtotalwage(double atotalwage) {
	this.atotalwage = atotalwage;
}

}
