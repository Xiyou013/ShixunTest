package shixun;

public class Department {
private String dno;
private String dname;
private String dphone;
private double abasicwage;
public String getDno() {
	return dno;
}
public void setDno(String dno) {
	this.dno = dno;
}
public String getDname() {
	return dname;
}
public void setDname(String dname) {
	this.dname = dname;
}
public String getDphone() {
	return dphone;
}
public void setDphone(String dphone) {
	this.dphone = dphone;
}
public double getAbasicwage() {
	return abasicwage;
}
public void setAbasicwage(double abasicwage) {
	this.abasicwage = abasicwage;
}

}
