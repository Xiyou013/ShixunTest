package shixun;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Xzcx {

	public void xzcx(Staff staff) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rsxxgl","root","root");
			String sql="select* from pay where Sno='"+staff.getSno()+"'";
			Statement st = con.createStatement();
			
			ResultSet res = st.executeQuery(sql);
			System.out.println("��ѯ�ɹ���");
			while(res.next()){
				System.out.println("\tԱ����\t|\t���ź�\t|\t��������\t|\t���ڹ���\t|\t�ܹ���");
				System.out.println("\t"+res.getString(1)+"\t|\t"+res.getString(2)+"\t|\t"+res.getString(3)
						+"\t|\t"+res.getString(4)+"\t|\t"+res.getString(5));
			}
			
			con.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
	}


	}



