package shixun;

public class Mencx {
	public static int mencx(String dno){
		if(dno.equals("")){
			return 0;
	    	}
		else if(dno.length()!=3){
				return 1;
    	}else{
    		return 2;
    	}
	}

	
}

