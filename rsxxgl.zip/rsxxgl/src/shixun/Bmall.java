package shixun;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class Bmall {
	public static void bmall(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql:"
					+ "//localhost:3306/rsxxgl","root","root");
			Statement st=con.createStatement();
			String sql="SELECT * FROM department;";
			ResultSet sel=st.executeQuery(sql);
			
			System.out.println("\t���ź�\t|\t������\t|\t���ŵ绰\t\t|\t��������");
			int num=0;
			while(sel.next()){
				String dno=sel.getString("dno");
				String dname=sel.getString("dname");
				String dphone=sel.getString("dphone");
				double abasicwage=sel.getDouble("abasicwage");
				num++;
				System.out.println(num+"\t"+dno+"\t|\t"+dname+"\t|\t"+dphone+"\t|\t"+abasicwage);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void bmsel(){
		try {
			System.out.println("�����벿�źŻ�������");
			Scanner input=new Scanner(System.in);
			String cz=input.nextLine().trim();
			Mimacy dnoys=new Mimacy();
	    	int bmdno=dnoys.bmdno(cz.trim());
	    	while(bmdno==0||bmdno==1||bmdno==2){
	    		if(bmdno==0){
	    			System.err.println("������Ĳ�����ϢΪ�գ�����������");
	    			 cz=input.nextLine().trim();
	    			 bmdno=dnoys.bmdno(cz.trim());
	    		}
	    		else if(bmdno==1){
	    			System.err.println("������Ĳ��źŲ����Ϲ���3λ����,�Ҳ������ո�");
	    			cz=input.nextLine().trim();
	    			 bmdno=dnoys.bmdno(cz.trim());
	    		}
	    		else if(bmdno==2){
	    			break;
	    		}
	    	}
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql:"
					+ "//localhost:3306/rsxxgl","root","root");
			Statement st=con.createStatement();
			String sql="SELECT * FROM department where dno='"+cz+"';";
			ResultSet sel=st.executeQuery(sql);
			if(sel.next()){
				String sql1="SELECT * FROM department where dno='"+cz+"';";
				ResultSet sel1=st.executeQuery(sql1);
				System.out.println("\t���ź�\t|\t������\t|\t���ŵ绰\t\t|\t��������");
				while(sel1.next()){
					String dno=sel1.getString("Dno");
					String dname=sel1.getString("Dname");
					String dphone=sel1.getString("Dphone");
					double abasicwage=sel1.getDouble("Abasicwage");
					System.out.println("\t"+dno+"\t|\t"+dname+"\t|\t"+dphone+"\t|\t"+abasicwage);
				}
			}else if(!sel.next()){
				String sql1="SELECT * FROM department where dname='"+cz+"';";
				ResultSet sel1=st.executeQuery(sql1);
				if(sel1.next()){
					String sql2="SELECT * FROM department where dname='"+cz+"';";
					ResultSet sel2=st.executeQuery(sql2);
					System.out.println("\t���ź�\t|\t������\t|\t���ŵ绰\t\t|\t��������");
					while(sel2.next()){
						String dno=sel2.getString("dno");
						String dname=sel2.getString("dname");
						String dphone=sel2.getString("dphone");
						double abasicwage=sel2.getDouble("abasicwage");
						System.out.println("\t"+dno+"\t|\t"+dname+"\t|\t"+dphone+"\t|\t"+abasicwage);
					}
				}else{
					System.err.println("�Ҳ����ò���");
				}	
			}else{
				System.err.println("�Ҳ����ò���");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
