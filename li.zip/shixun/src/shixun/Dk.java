package shixun;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class Dk {

	public void dk(Staff staff) {
		 try {
			 Scanner input=new Scanner(System.in);
			
			   System.out.println("��򿨣�");
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rsxxgl","root","root");
			    String sql = "update attendance set Psignin=Psignin+1 where sno='"+staff.getSno()+"'";
			    System.out.println(sql);
			    Statement st = con.createStatement();
				int res = st.executeUpdate(sql);
				System.out.println(res);
				
				if(res!=0){
					System.out.println("�򿨳ɹ���");
				}else{
					System.out.println("��ʧ�ܣ�");
				}
				
				con.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	

		
	}

