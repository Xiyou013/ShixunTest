package shixun;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import javax.swing.Icon;

public class Bmh {
	
	public static void bmh() {
		
		
		try {
			Scanner input=new Scanner(System.in);
	        System.out.println("-------  ������Ҫ��ѯ�Ĳ��ź�    ��010��011��012��013��    -------");
	        
			 
			   Staff staff = new Staff();
			   staff.setDno(input.nextLine().trim());
			   Mencx yg=new Mencx();
			   int ygnum=yg.mencx(staff.getDno().trim());
			   while(ygnum==0||ygnum==1||ygnum ==2){
			       if(ygnum==0){
			        System.err.println("������Ĳ��ź�Ϊ�գ����������룡");
			        staff.setDno(input.nextLine().trim());
			        ygnum=yg.mencx(staff.getDno().trim());
			       }
			       else if(ygnum==1){
			        System.err.println("����(010,011,012,013)��ѡ��");
			        staff.setDno(input.nextLine().trim());
			        ygnum=yg.mencx(staff.getDno().trim());
			       }
			       else if(ygnum==2){
			        break;
			       
			       }
			      }
			   
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rsxxgl","root","root");
			
			String sql="select* from department where Dno='"+staff.getDno()+"' ";
			System.out.println(sql);
			Statement st = con.createStatement();
			ResultSet res = st.executeQuery(sql);
			if(res.next()){
			   System.out.println("��ѯ�ɹ�!");
			   System.out.println("���źţ�"+res.getString(1)+"\r\n��������"+res.getString(2)+"\r\n������ϵ�绰��"+res.getString(3));
			    Ygjiemian ygmain=new Ygjiemian();
			  ygmain.ygjm();
			 }
			 else{
			   System.err.println("���źŲ����ڣ�����������");
			   bmh();
			  }
			System.out.println(res);
			//System.out.println(res.next());
			
			
			
			con.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}	

	

	
		
		

	
		
	

		
	

