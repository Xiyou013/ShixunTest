package shixun;

import java.util.Scanner;

public class Ygjiemian {
	public static void ygjm(){
		end:
		while(true){
			System.out.println("-------   ��ӭ��½Ա��ϵͳ        -------");
			System.out.println("-------     1.���Ų�ѯ              -------");
			System.out.println("-------     2.������Ϣ��ѯ       -------");
			System.out.println("-------     3.н�ʲ�ѯ              -------");
			System.out.println("-------     4.���ڲ�ѯ              -------");
			System.out.println("-------     5.��                     -------");
			System.out.println("-------     6.���                     -------");
			System.out.println("-------     7.�һ�����              -------");
			System.out.println("-------     0.����������           -------");
			System.out.println("-------������Ҫִ�еĲ������к� -------");
			Scanner input=new Scanner(System.in);
			int x=input.nextInt();
			switch(x){
			case 1:
				Bmcx bmcx = new Bmcx();
				bmcx.bmcx();
				break;
			case 4:
				Grcx grcx = new Grcx();
				grcx.grcx(Ygdl.staff);
				break;
			case 3:
				Xzcx xzcx = new Xzcx();
				xzcx.xzcx(Ygdl.staff);
				break;
			case 2:
				Gqcx kqcx = new Gqcx();
				kqcx.kqcx(Ygdl.staff);
				break;
			case 5:
				Dk dk = new Dk();
				dk.dk(Ygdl.staff);
				break;
			case 6:
				Qj qj = new Qj();
				qj.qj(Ygdl.staff);
				break;
			case 7:
	            Zpass zpass = new Zpass();
	            zpass.zpass(Ygdl.staff);
				break;
			case 0:
				Minterface mface=new Minterface();
				mface.zmuen();
				break end;
			default:
				System.out.println("������Ĳ�������ȷ������0-7֮��ѡ��!");
				break;
			}
		}
	}
}
