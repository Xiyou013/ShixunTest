package shixun;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Xzcx {

	public void xzcx(Staff staff) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rsxxgl","root","root");
			//String sql = "insert into user(uname,upass) values('"+uname+"','"+upass+"')";
			//String sql = "update user set upass='red56d' where uname='mara'";
			//String sql = "delete from user where uname='��ӽ'";
			String sql="select* from pay where Sno='"+staff.getSno()+"'";
			System.out.println(sql);
			Statement st = con.createStatement();
			
			ResultSet res = st.executeQuery(sql);
			System.out.println(res);
			System.out.println("��ѯ�ɹ���");
			//System.out.println(res.next());
			while(res.next()){
				System.out.println("Ա���ţ�"+res.getString(1)+"\r\n���ź�:"+res.getString(2)+"\r\n�������ʣ�"+res.getString(3)
				+"\r\n���ڹ��ʣ�"+res.getString(4)+"\r\n�ܹ��ʣ�"+res.getString(5));
			}
			
			con.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
	}


	}



