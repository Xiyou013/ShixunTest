package shixun;

public class Staff {
private String sno;
private String sname;
private String ssex;
private int sage;
private String sphone;
private String dno;
private String spass;
public String getSno() {
	return sno;
}
public void setSno(String sno) {
	this.sno = sno;
}
public String getSname() {
	return sname;
}
public void setSname(String sname) {
	this.sname = sname;
}
public String getSsex() {
	return ssex;
}
public void setSsex(String ssex) {
	this.ssex = ssex;
}
public int getSage() {
	return sage;
}
public void setSage(int sage) {
	this.sage = sage;
}
public String getSphone() {
	return sphone;
}
public void setSphone(String sphone) {
	this.sphone = sphone;
}
public String getDno() {
	return dno;
}
public void setDno(String dno) {
	this.dno = dno;
}
public String getSpass() {
	return spass;
}
public void setSpass(String spass) {
	this.spass = spass;
}
}