package shixun;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Gqcx {

	public void kqcx(Staff staff) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rsxxgl","root","root");
			//String sql = "insert into user(uname,upass) values('"+uname+"','"+upass+"')";
			//String sql = "update user set upass='red56d' where uname='mara'";
			//String sql = "delete from user where uname='��ӽ'";
			String sql="select* from staff where Sno='"+staff.getSno()+"'";
			System.out.println(sql);
			Statement st = con.createStatement();
			
			ResultSet res = st.executeQuery(sql);
			System.out.println(res);
			System.out.println("��ѯ�ɹ���");
			//System.out.println(res.next());
			while(res.next()){
				System.out.println("Ա������"+res.getString(3)+"\r\nԱ����:"+res.getString(2)+"\r\n�Ա�:"+res.getString(4)
				+"\r\n���䣺"+res.getString(5)+"\r\n�ֻ��ţ�"+res.getString(6)+"\r\n���źţ�"+res.getString(7)+"\r\n��ְʱ�䣺"
						+res.getString(8));
			}
			
			con.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
	}
}
