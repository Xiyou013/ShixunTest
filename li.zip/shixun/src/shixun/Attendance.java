package shixun;

public class Attendance {
private String sno;
private int psignin;
private String pleave;
private String pregleave;
public String getSno() {
	return sno;
}
public void setSno(String sno) {
	this.sno = sno;
}
public int getPsignin() {
	return psignin;
}
public void setPsignin(int psignin) {
	this.psignin = psignin;
}
public String getPleave() {
	return pleave;
}
public void setPleave(String pleave) {
	this.pleave = pleave;
}
public String getPregleave() {
	return pregleave;
}
public void setPregleave(String pregleave) {
	this.pregleave = pregleave;
}

}

